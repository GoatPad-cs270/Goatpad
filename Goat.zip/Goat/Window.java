package Goat;

public class Window {
	public Window(int x, int y) {

	}

	/**
	 * sets the height of the application
	 * 
	 * @param i
	 */
	public void setHeight(int i) {

	}

	/**
	 * set the width of the application
	 * 
	 * @param i
	 */
	public void setWidth(int i) {

	}

	/**
	 * returns width of application
	 * 
	 * @return
	 */
	public int getWidth() {
		return 0;
	}

	/**
	 * returns height of application
	 * 
	 * @return
	 */
	public int getHeight() {
		return 0;
	}
}
