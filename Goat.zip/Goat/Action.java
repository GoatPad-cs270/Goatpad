package Goat;

public class Action {

}
